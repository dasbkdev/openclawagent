import { validation } from "../domain/errors.js";

const refreshLocks = new Map();

export function createKickidlerClientFromEnv(env = process.env, options = {}) {
  const baseUrl = env.METRICON_BASE_URL || env.KICKIDLER_BASE_URL;
  const accessToken = env.METRICON_ACCESS_TOKEN || env.KICKIDLER_ACCESS_TOKEN;
  const refreshToken = env.METRICON_REFRESH_TOKEN || env.KICKIDLER_REFRESH_TOKEN;
  if (baseUrl && (accessToken || refreshToken)) {
    return new HttpKickidlerClient({
      baseUrl,
      accessToken,
      refreshToken,
      onTokenRefresh: options.onTokenRefresh,
    });
  }
  return new MockKickidlerClient();
}

export class MockKickidlerClient {
  constructor() {
    this.source = "mock";
    this.configured = false;
  }

  async getActivitySummary({ employeeIds, from, to }) {
    validateReportPeriod(from, to);
    return {
      source: this.source,
      configured: this.configured,
      from,
      to,
      employees: employeeIds.map((employeeId) => {
        const numeric = Number(employeeId) || 0;
        return {
          kickidlerEmployeeId: employeeId,
          activeSeconds: 14400 + numeric * 300,
          idleSeconds: 1200 + numeric * 60,
          lockSeconds: 600,
          topApplications: [
            { name: "IDE", seconds: 7200 },
            { name: "Browser", seconds: 3600 },
          ],
        };
      }),
    };
  }
}

export class HttpKickidlerClient {
  constructor({ baseUrl, accessToken, refreshToken, timeoutMs = 10000, onTokenRefresh = null }) {
    this.baseUrl = baseUrl.replace(/\/+$/, "");
    this.accessToken = accessToken || null;
    this.refreshToken = refreshToken || null;
    this.timeoutMs = timeoutMs;
    this.onTokenRefresh = onTokenRefresh;
    this.source = "metricon";
    this.configured = true;
  }

  async getActivitySummary({ employeeIds, from, to }) {
    validateReportPeriod(from, to);
    const employees = [];
    for (const employeeId of employeeIds) {
      const url = this.buildApiUrl("activity/report");
      url.searchParams.set("employeeId", String(employeeId));
      url.searchParams.set("from", from);
      url.searchParams.set("to", to);
      const payload = await this.fetchJson(url);
      employees.push({
        kickidlerEmployeeId: employeeId,
        raw: payload,
      });
    }

    return {
      source: this.source,
      configured: this.configured,
      from,
      to,
      employees,
    };
  }

  async fetchJson(url) {
    let retriedWithFreshToken = false;
    for (;;) {
      const accessToken = await this.getAccessToken();
      const response = await this.fetchWithTimeout(url, {
        method: "GET",
        headers: {
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
          Accept: "application/json",
        },
      });

      if (response.ok) {
        return await response.json();
      }

      if (!retriedWithFreshToken && this.refreshToken && response.status === 401) {
        retriedWithFreshToken = true;
        await this.refreshAccessToken();
        continue;
      }

      const text = await response.text();
      throw validation("Metricon API request failed", {
        status: response.status,
        body: text.slice(0, 1000),
      });
    }
  }

  async getAccessToken() {
    if (this.accessToken) {
      return this.accessToken;
    }
    if (this.refreshToken) {
      return await this.refreshAccessToken();
    }
    return null;
  }

  async refreshAccessToken() {
    if (!this.refreshToken) {
      throw validation("Metricon refresh token is not configured");
    }

    const lockKey = `${this.baseUrl}:${this.refreshToken}`;
    if (refreshLocks.has(lockKey)) {
      const tokens = await refreshLocks.get(lockKey);
      this.accessToken = tokens.accessToken;
      this.refreshToken = tokens.refreshToken || this.refreshToken;
      return this.accessToken;
    }

    const refreshPromise = this.performRefreshAccessToken();
    refreshLocks.set(lockKey, refreshPromise);
    try {
      const tokens = await refreshPromise;
      this.accessToken = tokens.accessToken;
      this.refreshToken = tokens.refreshToken || this.refreshToken;
      return this.accessToken;
    } finally {
      refreshLocks.delete(lockKey);
    }
  }

  async performRefreshAccessToken() {
    const response = await this.fetchWithTimeout(this.buildApiUrl("auth/refresh"), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ refreshToken: this.refreshToken }),
    });

    if (!response.ok) {
      const text = await response.text();
      throw validation("Metricon token refresh failed", {
        status: response.status,
        body: text.slice(0, 1000),
      });
    }

    const payload = await response.json();
    const data = payload?.data || payload;
    if (!data?.accessToken) {
      throw validation("Metricon token refresh response did not include accessToken");
    }

    const tokens = {
      accessToken: data.accessToken,
      refreshToken: data.refreshToken || this.refreshToken,
      expiresIn: data.expiresIn ?? null,
      tokenType: data.tokenType ?? null,
    };
    if (this.onTokenRefresh) {
      await this.onTokenRefresh(tokens);
    }
    return tokens;
  }

  buildApiUrl(pathname) {
    const cleanPath = String(pathname).replace(/^\/+/, "");
    const baseHasApiPrefix = /\/api\/v1$/iu.test(this.baseUrl);
    return new URL(`${this.baseUrl}/${baseHasApiPrefix ? "" : "api/v1/"}${cleanPath}`);
  }

  async fetchWithTimeout(url, options) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      return await fetch(url, {
        ...options,
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timer);
    }
  }
}

function validateReportPeriod(from, to) {
  if (!isIsoDateTime(from) || !isIsoDateTime(to)) {
    throw validation("from and to must be ISO date-time strings");
  }
  if (new Date(from).getTime() > new Date(to).getTime()) {
    throw validation("from must be before to");
  }
}

function isIsoDateTime(value) {
  return typeof value === "string" && Number.isFinite(new Date(value).getTime());
}
